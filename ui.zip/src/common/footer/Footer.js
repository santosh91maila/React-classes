import React from 'react'
import './Footer.css'

export const Footer = () => {
  return (
    <div className='footer'>&copy; rights belongs to me.</div>
  )
}
