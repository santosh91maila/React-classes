import "./C.css";
import React from "react";

function template() {
  return (
    <div className="c">
      <h1>C: {this.props.n} </h1>

    </div>
  );
};

export default template;
