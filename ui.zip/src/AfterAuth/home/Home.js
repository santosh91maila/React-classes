import React from 'react'
export const Home = () => {
  return (
    <h1 className='text-center'>Welcome...
    </h1>
  )
}
