import "./Header.css";
import React from "react";

function template() {
  return (
    <div className="header bg-primary text-white">
      My First React WebApplication
    </div>
  );
};

export default template;
