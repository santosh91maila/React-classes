import React from 'react'

 const Header = () => {
  return (
    <div className='header'>My Next JS App</div>
  )
}

export default Header
