import React from 'react'

export const About = () => {
  return (
    <h1 className='text-center'>About</h1>
  )
}

 
