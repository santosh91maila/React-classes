import React from 'react'
import './Header.css'

export const Header = () => {
  return (
    <div className='header py-1'>
        End-To-End Flow
    </div>
  )
}
