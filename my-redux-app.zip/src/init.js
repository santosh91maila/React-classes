export const nameInit={
    name:'Sachin',
   
}

export const locInit={
    loc:'Mumbai',
   
}