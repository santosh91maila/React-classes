import React from 'react'

export const PropsCheck = ({name}) => {
  return (
    <h1>Hellow {name || 'Dhoni'}</h1>
  )
}
