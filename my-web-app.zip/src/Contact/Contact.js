import React from 'react'

export const Contact = () => {
  return (
    <h1 className='text-center'>Contact</h1>
  )
}
