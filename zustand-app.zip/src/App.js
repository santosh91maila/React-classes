import logo from './logo.svg';
import './App.css';
import { A } from './A';
import { B } from './B';
import { C } from './C';
import { D } from './D';
function App() {
  return (
    <div className="App">
      <A />
      <B />
      <C />
      <D />
    </div>
  );
}

export default App;
