import React from 'react'

 const Footer = () => {
  return (
    <div className='footer'>&copy; rights belongs to me</div>
  )
}

export default Footer
