
import axios from "axios";

export class ServerCall{

  static  fnSendGetReq(url){
       return axios.get(url)
    }

  static  fnSendPostReq(){

    }

  static  fnSendPutReq(){

    }

   static fnSendDeleteReq(){

    }
}