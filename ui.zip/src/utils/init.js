export const init={
    loggedInUser:'',
    token:'',
    isShowLoader:false,
    modalInfo:{
        isShowModal:false,
        heading:'',
        cb:()=>{}
    }
}