import "./Footer.css";
import React from "react";

function template() {
  return (
    <div className="footer bg-primary text-white">
       &copy; rights belongs to me.
    </div>
  );
};

export default template;
