export const init={
    users:[],
    posts:[],
    photos:[],
    comments:[]
}