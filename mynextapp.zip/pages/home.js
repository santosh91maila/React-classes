import React from 'react'
import styles from '../styles/Home.module.css'

 const home = () => {
  return (
    <div className={styles.clr}>home</div>
  )
}

export default home
