import React from "react";

const appCtx=React.createContext()

export default appCtx