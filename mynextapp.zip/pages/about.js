import React from 'react'
import styles from '../styles/about.module.css'

 const about = () => {
  return (
    <div className={styles.clr}>about</div>
  )
}

export default about
