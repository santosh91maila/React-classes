import React from 'react'
import styles from '../styles/contact.module.css'
 const contact = () => {
  return (
    <div className={styles.clr}>contact</div>
  )
}

export default contact
