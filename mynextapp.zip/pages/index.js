
import home from './home'

export default home;
