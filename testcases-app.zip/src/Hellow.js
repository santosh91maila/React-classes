import React from 'react'

export const Hellow = () => {
  return (
    <h1>Hellow Sachin</h1>
  )
}
